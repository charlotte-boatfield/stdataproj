if yn = yes {
	showhide = style.display.block
} else {
	yn = 
} showhide = style.display.hidden